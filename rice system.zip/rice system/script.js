document.addEventListener('DOMContentLoaded', function () {
    displayReservedNames();
});

function reserveName() {
    const nameInput = document.getElementById('name');
    const reservedNamesContainer = document.getElementById('reservedNames');

    const name = nameInput.value.trim();

    if (name === '') {
        alert('Please enter a valid name.');
        return;
    }

    // Get existing reserved names from local storage
    let reservedNames = JSON.parse(localStorage.getItem('reservedNames')) || [];

    // Check if the name is already reserved
    if (reservedNames.includes(name)) {
        alert('This name is already reserved.');
        return;
    }

    // Add the new name to the list of reserved names
    reservedNames.push(name);

    // Save the updated list to local storage
    localStorage.setItem('reservedNames', JSON.stringify(reservedNames));

    // Display the reserved names
    displayReservedNames();

    // Clear the input field
    nameInput.value = '';
}

function displayReservedNames() {
    const reservedNamesContainer = document.getElementById('reservedNames');
    const reservedNames = JSON.parse(localStorage.getItem('reservedNames')) || [];

    if (reservedNames.length > 0) {
        reservedNamesContainer.textContent = 'Reserved Names: ' + reservedNames.join(', ');
    } else {
        reservedNamesContainer.textContent = 'No names reserved yet.';
    }
}
